#analysepackage
This library was created  for the analyse hackathon challenge and how to be able to publish it on GitHub

## building this package locaally
'python setup.py sdist'

## installing this package from GitHub
'pip install fit+https://github.com/Phumzile-Madonsela/analyse-hackathon-python-package.git'

## updating this package from GitHub
'pip install --upgrade git+https://github.com/Phumzile-Madonsela/analyse-hackathon-python-package.git'